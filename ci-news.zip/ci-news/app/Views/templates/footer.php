
<footer class="mt-auto text-white-50" style="background-color: #212F3C;">
  <br>
    <center><p style="color: white">Derechos de autor Nataly Molano Mendieta © 2023 </p></center>
    <br>
  </footer>
</body>
</html>