
<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvendida</title>
    <!-- CSS only -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Audiowide">
</head>
<style>

th, td {
    border-style:solid;
    border-color: #96D4D4;
  }
  input
  {
      border-style:solid;
      border-color: #96D4D4;
      background-color: transparent;
      color: #96D4D4;
      font-family: "Audiowide", sans-serif;
      
  }
  table {
      width: 100%;
      height: 400px;
  }
  body
  {
      text-align: center;
      font-family: "Audiowide", sans-serif;
      color:#96D4D4;
      background-image: url("fondo_morado.jpg");
      background-size: cover;
  }
  button
  {
      font-family: "Audiowide", sans-serif;
      border-color: #96D4D4;
      background-color: transparent;
      color: #96D4D4;
      padding: 10px;
  }
  button:visited {
  color: burlywood;
  background-color: transparent;
  text-decoration: none;
  }
  button:hover {
  color: blue;
  background-color: transparent;
  text-decoration: underline;
  }
  button:active {
  color: yellow;
  background-color:blue;
  text-decoration: underline;
  }
    body{
        background-image: url("");
        background-color: black;
        background-size: cover;
        font-family: "Audiowide", sans-serif;
        color: antiquewhite;
        margin-top: 3cm;
    }
    
    button
    {
        padding: 7px;
    }
</style>
<body>
<h2>BIENVENIDO AL MENU<br>DE INSTRUCCIONES</h2><BR>

<h4>Para iniciar a jugar tenemos el tablero el cual es 3X3,podemos obsevar que los campos estan enumerados<br> entre parentecis y dos numeros (f,c) los numeros que se encuentran en la posicion f son las filas mientras<br> los que se encuentran en la posicion c son las columnas</h4>
<center>
  <table style="width:50%">
    <tr>
      <th>(0,0)<br></th>
      <th>(0,1) </th> 
      <th>(0,2) </th>
    </tr>
    <tr>
        <th>(1,0)<br></th>
        <th>(1,1) </th> 
        <th>(1,2) </th>
    </tr>
    <tr>
        <th>(2,0)<br></th>
        <th>(2,1) </th> 
        <th>(2,2) </th>
    </tr>
    
  </table></center><br>
  <h3>En la parte inferior de la pagina tenemos dos campos que se llenan que es el de la fila<br>y columna estos campos se llenan con el numerero de la posicion del campo que desea<br>llenar en la tabla, luego de seleccionar la posicion presione el boton de seleccionar<br>y el campo se rellenara con una X</h3>
  <center><form action="/action_page.php">
    <label for="f">Ingrese la fila</label>
    <input type="text" id="f" name="f" >
    <label for="c">Ingrese la columna</label>
    <input type="text" id="c" name="c" ><br>
    <button type="button" class="btn btn-light">Seleccionar</button>
    <button type="button" class="btn btn-light">Retroceder</button>

  </form> 
    <!-- JavaScript Bundle with Popper -->
</body>
</html>