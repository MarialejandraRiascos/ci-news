<?php

namespace App\Controllers;
//comprueba si la pagina existe, validar que el archivo exista si no existe se genera El Page NofontExpetion
use CodeIgniter\Exceptions\PageNotFoundException; // Add this line

class Pages extends BaseController
{

    public function view($page = 'juego')
    {
        //Si es diferente la existencia de un archivo se hace el retunamiento
        if (! is_file(APPPATH . 'Views/pages/' . $page . '.php')) {
            // Encapsulamiento, optiene el error y muestro el erro
            throw new PageNotFoundException($page);
        }
        //El tittle nombre de la pagina y mantener un estandar 
        $data['title'] = ucfirst($page); // Capitalize the first letter
        //3 tipos de return que retorne 3 vistas diferentes
        return view('templates/header', $data)
        //el . concatena, parametro page, parametro la pagina , body
            . view('pages/' . $page)
        //pie de pagina
            . view('templates/footer');
    }
}